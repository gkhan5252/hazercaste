![Ekran görüntüsü 2023-12-27 154517](https://github.com/ErayKeles/HazelcastEray/assets/128937269/fcce688a-5a93-4809-9589-d917e7bbe235)


![Ekran görüntüsü 2023-12-27 154524](https://github.com/ErayKeles/HazelcastEray/assets/128937269/173470ec-616d-48ba-930f-ae98949367c0)

![Ekran görüntüsü 2023-12-27 165525](https://github.com/ErayKeles/HazelcastEray/assets/128937269/1a74dcdb-c812-42bc-85a9-0ee25be017dc)
